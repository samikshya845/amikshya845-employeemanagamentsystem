package com.example.employee_management_system.dto;

import lombok.Data;

@Data
public class RoleDTO {
    private Long id;
    private String name;
}
