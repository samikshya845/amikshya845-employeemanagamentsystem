package com.example.employee_management_system.dto;


import lombok.Data;

@Data
public class DepartmentDTO {
    private Long id;
    private String name;
}