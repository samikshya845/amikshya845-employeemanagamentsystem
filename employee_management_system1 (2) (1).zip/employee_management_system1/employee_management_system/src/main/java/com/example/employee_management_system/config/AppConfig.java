package com.example.employee_management_system.config;

public interface AppConfig {

}
